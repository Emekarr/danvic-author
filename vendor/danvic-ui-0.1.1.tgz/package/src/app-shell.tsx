'use client'

import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import { useState, type ComponentType, type ReactNode } from 'react'
import {
  Award,
  BookOpen,
  ChevronDown,
  CircleHelp,
  FilePlus2,
  Home,
  Library,
  LockKeyhole,
  LogOut,
  GraduationCap,
  MailPlus,
  ClipboardCheck,
  CalendarDays,
  CreditCard,
  Menu,
  Settings2,
  ScanLine,
  ShieldCheck,
  UserRound,
  Users,
  Video,
  X,
} from 'lucide-react'

export interface NavigationItem {
  label: string
  href: string
  icon: ComponentType<{ 'aria-hidden'?: boolean }>
  disabled?: boolean
}

export interface NavigationGroup {
  label?: string
  items: NavigationItem[]
}

const navigationByKind: Record<'admin' | 'author' | 'learner', NavigationGroup[]> = {
  admin: [
    { items: [{ label: 'Overview', href: '/dashboard', icon: Home }] },
    {
      label: 'Manage',
      items: [
        { label: 'Authors', href: '/authors', icon: Users },
        { label: 'Students', href: '/students', icon: GraduationCap },
        { label: 'Admins', href: '/admins', icon: ShieldCheck },
        { label: 'Courses', href: '/courses', icon: BookOpen },
      ],
    },
    { label: 'Account', items: [{ label: 'Security', href: '/security', icon: LockKeyhole }] },
  ],
  author: [
    { items: [{ label: 'Overview', href: '/dashboard', icon: Home }] },
    {
      label: 'Courses',
      items: [
        { label: 'Courses', href: '/courses', icon: BookOpen },
        { label: 'Live classes', href: '/live-classes', icon: Video },
        { label: 'Calendar', href: '/calendar', icon: CalendarDays, disabled: true },
      ],
    },
    { label: 'Billing', items: [{ label: 'Transactions', href: '/payments', icon: CreditCard }] },
    {
      label: 'Assessment',
      items: [{ label: 'Assessments', href: '/assessments', icon: ClipboardCheck }],
    },
    {
      label: 'Account',
      items: [
        { label: 'Profile', href: '/profile', icon: UserRound },
        { label: 'Security', href: '/security', icon: LockKeyhole },
      ],
    },
  ],
  learner: [
    { items: [{ label: 'Home', href: '/dashboard', icon: Home }] },
    {
      label: 'Learning',
      items: [
        { label: 'My courses', href: '/courses', icon: BookOpen },
        { label: 'Course catalog', href: '/catalog', icon: Library },
        { label: 'Assessments', href: '/assessments', icon: ClipboardCheck },
        { label: 'Certificates', href: '/certificates', icon: Award },
      ],
    },
    {
      label: 'Account',
      items: [
        { label: 'Profile', href: '/profile', icon: UserRound },
        { label: 'Verify certificate', href: '/verify-certificate', icon: ScanLine },
        { label: 'Payments', href: '/payments', icon: CreditCard },
        { label: 'Security', href: '/security', icon: LockKeyhole },
      ],
    },
  ],
}

const nestedNavigationPaths: Partial<
  Record<'admin' | 'author' | 'learner', Record<string, string[]>>
> = {
  author: {
    '/courses': ['/course'],
  },
  learner: {
    '/courses': ['/course'],
    '/assessments': ['/assessment-attempts'],
    '/catalog': ['/authors'],
  },
}

export function AppShell({
  kind,
  displayName,
  email,
  children,
  navigationOverride,
  loginHref = '/login',
  topbarActions,
  authenticated = true,
  onLogout,
}: {
  kind: 'admin' | 'author' | 'learner'
  displayName: string
  email: string
  children: ReactNode
  navigationOverride?: NavigationGroup[]
  loginHref?: string
  topbarActions?: ReactNode
  authenticated?: boolean
  onLogout?: () => Promise<void>
}) {
  const pathname = usePathname()
  const router = useRouter()
  const [mobileOpen, setMobileOpen] = useState(false)
  const navigation = navigationOverride ?? navigationByKind[kind]
  const initials = displayName
    .split(/\s+/)
    .map((part) => part[0])
    .join('')
    .slice(0, 2)
    .toUpperCase()
  const role =
    kind === 'admin' ? 'Public administrator' : kind === 'author' ? 'Course author' : 'Learner'

  const logout = async () => {
    if (onLogout) await onLogout().catch(() => null)
    else await fetch('/api/auth/logout', { method: 'POST' }).catch(() => null)
    router.push(loginHref)
    router.refresh()
  }

  return (
    <div className="sb-app-shell" data-kind={kind}>
      <a href="#main-content" className="sb-skip-link">
        Skip to main content
      </a>
      {mobileOpen ? (
        <button
          className="sb-mobile-backdrop"
          aria-label="Close navigation"
          onClick={() => setMobileOpen(false)}
        />
      ) : null}
      <aside className="sb-sidebar" data-open={mobileOpen} aria-label={`${kind} navigation`}>
        <div className="sb-workspace-label">
          <strong>{kind === 'admin' ? 'DANVIC LMS' : 'DANVIC'}</strong>
          <small>{role}</small>
        </div>
        <nav className="sb-nav">
          {navigation.map((group, groupIndex) => (
            <div key={group.label ?? groupIndex}>
              {group.label ? <p className="sb-nav-label">{group.label}</p> : null}
              {group.items.map((item) => {
                const matchesPath = (entry: NavigationItem) =>
                  [entry.href, ...(nestedNavigationPaths[kind]?.[entry.href] ?? [])].some(
                    (path) =>
                      pathname === path ||
                      (path !== '/' && (pathname ?? '').startsWith(`${path}/`)),
                  )
                const matchingItems = navigation
                  .flatMap((entry) => entry.items)
                  .filter(matchesPath)
                const active = matchingItems.some(
                  (entry) =>
                    entry.href === item.href &&
                    entry.href.length ===
                      Math.max(...matchingItems.map((match) => match.href.length)),
                )
                const Icon = item.icon
                if (item.disabled)
                  return (
                    <span
                      key={item.href}
                      className="sb-nav-link sb-nav-link--disabled"
                      aria-disabled="true"
                    >
                      <Icon aria-hidden={true} />
                      <span>{item.label}</span>
                      <small>Soon</small>
                    </span>
                  )
                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    className="sb-nav-link"
                    aria-current={active ? 'page' : undefined}
                    onClick={() => setMobileOpen(false)}
                  >
                    <Icon aria-hidden={true} />
                    <span>{item.label}</span>
                  </Link>
                )
              })}
            </div>
          ))}
        </nav>
        <div className="sb-sidebar-footer">
          <a href="mailto:support@danvic.com" className="sb-nav-link">
            <CircleHelp aria-hidden="true" />
            <span>Help & support</span>
          </a>
        </div>
      </aside>
      <div className="sb-main">
        <header className="sb-topbar">
          <button
            className="sb-icon-button sb-mobile-menu"
            onClick={() => setMobileOpen((value) => !value)}
            aria-label={mobileOpen ? 'Close navigation' : 'Open navigation'}
          >
            {mobileOpen ? <X aria-hidden="true" /> : <Menu aria-hidden="true" />}
          </button>
          <div className="sb-top-actions">
            {topbarActions}
            <details className="sb-user-menu">
              <summary className="sb-user-chip">
                <span className="sb-avatar">{initials}</span>
                <span className="sb-user-chip-meta">
                  <strong>{displayName}</strong>
                  <small>{role}</small>
                </span>
                <ChevronDown className="sb-chevron" aria-hidden="true" />
              </summary>
              <div className="sb-user-menu-popover">
                <div className="sb-user-menu-header">
                  <strong>{displayName}</strong>
                  <small>{email}</small>
                </div>
                {authenticated ? (
                  <button
                    className="sb-menu-item sb-menu-item--danger"
                    type="button"
                    onClick={() => void logout()}
                  >
                    <LogOut aria-hidden="true" /> Sign out
                  </button>
                ) : (
                  <Link className="sb-menu-item" href={loginHref}>
                    <LogOut aria-hidden="true" /> Sign in
                  </Link>
                )}
              </div>
            </details>
          </div>
        </header>
        <main id="main-content" className="sb-content">
          {children}
        </main>
      </div>
    </div>
  )
}
