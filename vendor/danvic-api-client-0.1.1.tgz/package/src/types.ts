export type LoginResult =
  | { status: 'authenticated'; next: string }
  | { status: 'two-factor-required'; next: string }
  | { status: 'two-factor-setup-required'; next: string }

export type ContentType =
  | 'lesson'
  | 'video'
  | 'document'
  | 'assignment'
  | 'quiz'
  | 'exam'
  | 'question'

export type ReviewStatus =
  | 'draft'
  | 'pending_review'
  | 'approved'
  | 'rejected'
  | 'needs_revision'

export type PublicationStatus = 'unpublished' | 'published' | 'archived'

export type ReviewCriterion =
  | 'technical_accuracy'
  | 'brand_consistency'
  | 'copyright_ip'
  | 'safety_regulatory'
  | 'content_quality'

export interface ContentAuthorRef {
  id: string
  firstName: string
  lastName: string
  email: string
}

export interface ContentVersion {
  id: string
  contentId: string
  label: string
  number: number
  state: 'draft' | 'submitted' | 'approved' | 'published' | 'superseded'
  changeSummary: string | null
  createdBy: ContentAuthorRef
  createdAt: string
  updatedAt: string
  publishedAt: string | null
}

export interface CriterionReview {
  criterion: ReviewCriterion
  score: number | null
  comment: string | null
}

export interface ContentReview {
  id: string
  contentId: string
  versionId: string
  decision: 'approved' | 'rejected' | 'needs_revision'
  summary: string
  reviewer: ContentAuthorRef
  criteria: CriterionReview[]
  createdAt: string
}

export interface ReviewableContent {
  id: string
  title: string
  type: ContentType
  courseId: string | null
  courseName: string | null
  author: ContentAuthorRef
  reviewStatus: ReviewStatus
  publicationStatus: PublicationStatus
  currentVersion: ContentVersion
  submittedAt: string | null
  approvedAt: string | null
  publishedAt: string | null
  archivedAt: string | null
  rejectionReason: string | null
  reviewScores: Partial<Record<ReviewCriterion, number>>
  nextReviewAt: string | null
  updatedAt: string
}

export interface PaginatedResult<T> {
  items: T[]
  page: { number: number; limit: number; total: number; totalPages: number }
  filters: {
    authors: ContentAuthorRef[]
    types: ContentType[]
    statuses: Array<ReviewStatus | PublicationStatus>
  }
}

export interface MfaPolicy {
  admins: { login: 'required' }
  authors: { login: 'required' }
  students: { login: 'optional'; beforeEnrollment: 'required' }
}

export interface SecurityPolicyResponse {
  policy: MfaPolicy
  canManageMfaPolicy: boolean
}

export interface AdminProfile {
  id: string
  firstName: string
  lastName: string
  email: string
  permissions: string[]
  isSuperAdmin: boolean
  twoFactorEnabled: boolean
  createdAt: string
  updatedAt: string
}

export interface AdminDirectoryEntry extends AdminProfile {
  disabledAt: string | null
}

export interface AdminNotification {
  id: string
  title: string
  body: string
  link?: string
  readAt: string | null
  createdAt: string
}

export interface AuthorProfile {
  id: string
  firstName: string
  lastName: string
  email: string
  bio: string
  linkedInUrl: string | null
  xUrl: string | null
  instagramUrl: string | null
  facebookUrl: string | null
  websiteUrl: string | null
  twoFactorEnabled: boolean
  createdAt: string
  updatedAt: string
}

export interface AuthorDirectoryEntry extends AuthorProfile {
  disabledAt: string | null
  courseCount: number
}

export interface PublicAuthorProfile {
  author: Pick<
    AuthorProfile,
    | 'id'
    | 'firstName'
    | 'lastName'
    | 'bio'
    | 'linkedInUrl'
    | 'xUrl'
    | 'instagramUrl'
    | 'facebookUrl'
    | 'websiteUrl'
  >
  courses: Course[]
  rating: { average: number; count: number }
}

export interface StudentProfile {
  id: string
  firstName: string
  lastName: string
  email: string
  bio: string
  linkedInUrl: string | null
  xUrl: string | null
  facebookUrl: string | null
  instagramUrl: string | null
  youtubeUrl: string | null
  websiteUrl: string | null
  twoFactorEnabled: boolean
  createdAt: string
  updatedAt: string
}

export interface StudentDirectoryEntry extends StudentProfile {
  disabledAt: string | null
}

export interface InvitationRecord {
  id: string
  email: string
  invitedByAdminId: string
  courseId?: string | null
  invitedByType?: 'admin' | 'author'
  invitedById?: string
  expiresAt: string
  sentAt: string | null
  acceptedAt: string | null
  deliveryError: string | null
  resendCount?: number
  lastResentAt?: string | null
  createdAt: string
  updatedAt: string
}

export interface CourseEnrollment {
  id: string
  courseId: string
  studentId: string
  source: 'free' | 'payment' | 'invitation'
  invitationId: string
  paymentReference: string | null
  enrolledAt: string
  completedAt: string | null
  progressResetHistory: Array<{
    resetAt: string
    reason: 'course_modules_changed'
    completedModuleIds: string[]
    completedAt: string | null
  }>
  createdAt: string
  updatedAt: string
}

export interface ModuleProgress {
  id: string
  enrollmentId: string
  courseId: string
  moduleId: string
  studentId: string
  completedAt: string
  createdAt: string
  updatedAt: string
}

export interface StudentCourseAggregate extends CourseAggregate {
  enrollment: CourseEnrollment
  completedModuleIds: string[]
  certificate: Certificate | null
  authorRating: number | null
}

export interface StudentEnrollmentSummary {
  enrollment: CourseEnrollment
  completedModules: ModuleProgress[]
  moduleCount: number
  course: Course | null
  certificate?: Certificate | null
  authorName?: string | null
}

export interface Certificate {
  id: string
  certificateNumber: string
  studentId: string
  studentName: string
  courseId: string
  courseName: string
  completedAt: string
  issuedAt: string
  revokedAt: string | null
  createdAt: string
  updatedAt: string
}

export type CertificateVerification =
  | { recognized: false; valid: false; certificate: null }
  | {
      recognized: true
      valid: boolean
      certificate: Pick<
        Certificate,
        | 'certificateNumber'
        | 'studentName'
        | 'courseName'
        | 'completedAt'
        | 'issuedAt'
        | 'revokedAt'
      >
      verificationUrl: string
    }

export interface CourseParticipant {
  enrollment: CourseEnrollment
  completedModules: ModuleProgress[]
  student: { id: string; firstName: string; lastName: string; email: string }
  moduleCount: number
  completedCount: number
  assessment: {
    attempt: AssessmentAttempt | null
    status: AssessmentAttempt['status'] | 'not_started'
    score: number | null
    passed: boolean | null
  } | null
}

export interface Course {
  id: string
  name: string
  durationMinutes: number
  type: 'live' | 'premade'
  liveCallDurationMinutes: number | null
  certificateOnCompletion: boolean
  scheduledAt: string | null
  accessType: 'free' | 'paid'
  priceKobo: number
  createdByAuthorId: string
  createdAt: string
  updatedAt: string
  imageUrls?: string[]
}

export interface CatalogCourse extends Course {
  authorName: string
}

export interface LiveReminderPreference {
  courseId: string
  enabled: boolean
  reminderAt: string | null
  deliveredAt: string | null
  deliveryError: string | null
  updatedAt: string
}

export interface InitializedCoursePayment {
  status: 'initialized'
  reference: string
  authorizationUrl: string
  accessCode: string
  purpose: 'course_purchase' | 'card_setup'
}

export interface VerifiedCoursePayment {
  status: 'success'
  reference: string
  purpose: 'course_purchase' | 'card_setup'
  courseId: string | null
  enrollmentId: string | null
  cardSaved: boolean
  refundStatus?: string
}

export interface SavedPaymentMethod {
  id: string
  adapter: 'paystack'
  channel: string
  cardType: string
  brand: string
  last4: string
  expMonth: string
  expYear: string
  bank: string
  countryCode: string
  accountName: string | null
  createdAt: string
  updatedAt: string
}

export interface PaymentTransaction {
  id: string
  reference: string
  purpose: 'course_purchase' | 'card_setup'
  courseId: string | null
  amountKobo: number
  currency: 'NGN'
  adapter: 'paystack'
  status: 'pending' | 'initialized' | 'succeeded' | 'failed'
  paymentMethod: string | null
  gatewayResponse: string | null
  feesKobo: number | null
  bankName: string | null
  accountName: string | null
  cardBrand: string | null
  cardType: string | null
  cardLast4: string | null
  countryCode: string | null
  refundStatus: 'requesting' | 'pending' | 'processing' | 'processed' | 'failed' | null
  paidAt: string | null
  createdAt: string
}

export interface StudentPayments {
  paymentMethods: SavedPaymentMethod[]
  transactions: PaymentTransaction[]
  cardSetupAmountKobo: number
}

export interface AuthorPaymentTransaction extends PaymentTransaction {
  customerEmail: string
}

export interface CourseModule {
  id: string
  courseId: string
  title: string
  content: string
  order: number
  createdAt: string
  updatedAt: string
}

export interface Attachment {
  id: string
  courseId: string
  courseName: string
  moduleId: string | null
  attachmentPath: string
  fileName?: string
  createdAt: string
  updatedAt: string
}

export interface CourseAggregate {
  course: Course
  modules: CourseModule[]
  attachments: Attachment[]
}

export interface AuthorReference {
  id: string
  firstName: string
  lastName: string
  email: string
}

export interface AdminCourseEntry {
  course: Course
  author: AuthorReference | null
}

export interface AdminCourseDetail extends CourseAggregate {
  author: AuthorReference | null
  assessment: Assessment | null
  participants: AdminCourseParticipant[]
}

export interface AdminAuthorCourse {
  course: Course
  enrolledCount: number
  completedCount: number
}

export interface AdminAuthorDetail {
  author: Omit<AuthorDirectoryEntry, 'courseCount'>
  courses: AdminAuthorCourse[]
}

export interface AdminStudentCourse {
  course: Course | null
  enrollment: CourseEnrollment
  completedCount: number
  moduleCount: number
  assessment: {
    title: string
    attempt: AssessmentAttempt | null
    attempts: AssessmentAttempt[]
  } | null
  certificate: Certificate | null
}

export interface AdminStudentDetail {
  student: Omit<StudentDirectoryEntry, 'disabledAt'> & { disabledAt: string | null }
  courses: AdminStudentCourse[]
}

export interface AdminCourseParticipant extends CourseParticipant {
  assessmentAttempt: AssessmentAttempt | null
  assessmentAttempts: AssessmentAttempt[]
  certificate: Certificate | null
}

export interface CoursePreview {
  course: Course
  modules: Array<Pick<CourseModule, 'id' | 'courseId' | 'title' | 'order'>>
  attachments: Array<{
    id: string
    courseId: string
    courseName: string
    fileName: string
  }>
}

export interface SignedUpload {
  uploadUrl: string
  attachmentPath: string
  viewUrl: string
  expiresInSeconds: number
  requiredHeaders: Record<string, string>
}

export type AssessmentQuestionType = 'multiple_choice' | 'free_text'
export type AssessmentMediaType = 'image' | 'video' | 'audio'

export interface AssessmentOption {
  id: string
  label: string
}

export interface AssessmentQuestionResource {
  id: string
  fileName: string
  attachmentPath?: string
  url?: string | null
}

export interface AssessmentQuestion {
  id: string
  prompt: string
  type: AssessmentQuestionType
  options: AssessmentOption[]
  correctOptionIds?: string[]
  mediaType: AssessmentMediaType | null
  mediaUrl: string | null
  resources?: AssessmentQuestionResource[]
  points: number
}

export interface Assessment {
  id: string
  title: string
  description: string
  authorId: string
  courseId: string | null
  durationMinutes: number
  opensAt: string
  closesAt: string
  manualReview: boolean
  retrySupported: boolean
  maxAttempts: number
  passingScorePercent: number
  questions: AssessmentQuestion[]
  createdAt: string
  updatedAt: string
  submissionCount?: number
  attempt?: AssessmentAttempt | null
  attemptHistory?: AssessmentAttemptSummary[]
  attemptsRemaining?: number
  availability?: 'scheduled' | 'open' | 'closed'
}

export type AssessmentAttemptStatus = 'in_progress' | 'pending_review' | 'graded'

export interface AssessmentAnswer {
  questionId: string
  selectedOptionIds: string[]
  text: string | null
  awardedPoints: number | null
  feedback: string | null
}

export interface AssessmentAttempt {
  id: string
  assessmentId: string
  studentId: string
  courseId: string | null
  attemptNumber: number
  status: AssessmentAttemptStatus
  startedAt: string
  submittedAt: string | null
  expiresAt: string
  score: number | null
  maxScore: number
  passed: boolean | null
  answers: AssessmentAnswer[]
  reviewedAt: string | null
  reviewedByAuthorId: string | null
  student?: { id: string; firstName: string; lastName: string; email: string }
  assessmentTitle?: string
}

export interface AssessmentAttemptSummary {
  id: string
  attemptNumber: number
  status: AssessmentAttemptStatus
  score: number | null
  maxScore: number
  passed: boolean | null
  startedAt: string
  submittedAt: string | null
}

export type LiveSessionStatus = 'scheduled' | 'live' | 'ended'
export interface LiveSession {
  id: string
  courseId: string | null
  authorId: string
  channelName: string
  durationMinutes: number
  status: LiveSessionStatus
  scheduledAt: string | null
  startedAt: string | null
  endedAt: string | null
  expiresAt: string | null
  whiteboardRoomUuid: string | null
  whiteboardActive: boolean
  whiteboardUsedAt: string | null
  cameraDefaultOff: boolean
  createdAt: string
  updatedAt: string
}

export interface LiveParticipant {
  id: string
  sessionId: string
  courseId: string
  actorType: 'author' | 'student'
  actorId: string
  displayName: string
  rtcUid: number
  joinedAt: string
  leftAt: string | null
  lastSeenAt: string
  microphoneOn: boolean
  cameraOn: boolean
  screenSharing: boolean
  handRaised: boolean
  canPublish: boolean
  kickedAt: string | null
  bannedAt: string | null
}

export interface LiveMessage {
  id: string
  sessionId: string
  actorType: 'author' | 'student'
  actorId: string
  displayName: string
  kind: 'chat' | 'reaction' | 'system'
  body: string
  createdAt: string
  updatedAt: string
}

export interface LiveRecording {
  id: string
  courseId: string
  sessionId: string
  sequence: number
  type: 'web' | 'audio'
  status: 'starting' | 'recording' | 'stopping' | 'processing' | 'ready' | 'failed'
  startedAt: string
  stoppedAt: string | null
  durationSeconds: number | null
  viewOnly: true
  failureReason: string | null
  createdAt: string
  updatedAt: string
}

export interface WhiteboardJoinConfig {
  appIdentifier: string
  roomUuid: string
  roomToken: string
  writable: boolean
}

export interface LiveJoinConfig {
  session: LiveSession
  participant: LiveParticipant
  appId: string
  channelName: string
  rtcToken: string
  uid: number
  role: 'host' | 'audience'
  cameraDefaultOff: true
  whiteboard: WhiteboardJoinConfig | null
}

export interface LiveState {
  session: LiveSession
  participants: LiveParticipant[]
  messages: LiveMessage[]
}
